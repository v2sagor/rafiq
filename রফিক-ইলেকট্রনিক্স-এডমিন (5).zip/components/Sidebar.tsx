
import React from 'react';
import { LayoutDashboard, Users, CreditCard, LogOut } from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  setCurrentPage: (page: 'dashboard' | 'customers' | 'billing') => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentPage, setCurrentPage, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: LayoutDashboard },
    { id: 'customers', label: 'গ্রাহক তালিকা', icon: Users },
    { id: 'billing', label: 'বিল এন্ট্রি', icon: CreditCard },
  ];

  return (
    <aside className="w-72 bg-white border-r border-slate-200 h-screen sticky top-0 hidden md:flex flex-col shadow-sm">
      <div className="p-10 border-b border-slate-100">
        <div className="flex flex-col items-center">
          <h1 className="text-xl font-black text-slate-800 leading-tight">রফিক ইলেকট্রনিক্স</h1>
          <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mt-1 text-center">Electronics & Network</p>
        </div>
      </div>
      
      <nav className="flex-1 p-6 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id as any)}
              className={`w-full flex items-center space-x-3 px-4 py-3.5 rounded-xl transition-all duration-200 ${
                currentPage === item.id 
                ? 'bg-orange-600 text-white shadow-lg shadow-orange-200' 
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Icon size={20} strokeWidth={2.5} />
              <span className="font-bold">{item.label}</span>
            </button>
          );
        })}
      </nav>
      
      <div className="p-6 border-t border-slate-100">
        <button 
          onClick={onLogout}
          className="w-full flex items-center space-x-3 px-4 py-3.5 rounded-xl text-red-500 hover:bg-red-50 transition-all duration-200 font-bold"
        >
          <LogOut size={20} strokeWidth={2.5} />
          <span>লগআউট করুন</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
