
import React, { useState, useEffect } from 'react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import Billing from './pages/Billing';
import Sidebar from './components/Sidebar';
import { Customer, BillRecord } from './types';
import { getStoredData, setStoredData } from './services/storage';
import { Menu, X } from 'lucide-react';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'customers' | 'billing'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [bills, setBills] = useState<BillRecord[]>([]);

  useEffect(() => {
    const data = getStoredData();
    setCustomers(data.customers);
    setBills(data.bills);
    
    const auth = localStorage.getItem('isLoggedIn');
    if (auth === 'true') {
      setIsLoggedIn(true);
    }
  }, []);

  useEffect(() => {
    setStoredData({ customers, bills });
  }, [customers, bills]);

  const handleLogin = (status: boolean) => {
    setIsLoggedIn(status);
    if (status) {
      localStorage.setItem('isLoggedIn', 'true');
    } else {
      localStorage.removeItem('isLoggedIn');
      localStorage.removeItem('rafiq_electronics_data'); 
    }
  };

  if (!isLoggedIn) {
    return <Login onLoginSuccess={() => handleLogin(true)} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard customers={customers} bills={bills} onNavigate={(page) => setCurrentPage(page)} />;
      case 'customers':
        return <Customers customers={customers} setCustomers={setCustomers} />;
      case 'billing':
        return <Billing customers={customers} bills={bills} setBills={setBills} />;
      default:
        return <Dashboard customers={customers} bills={bills} onNavigate={(page) => setCurrentPage(page)} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 relative overflow-x-hidden">
      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 md:hidden backdrop-blur-sm transition-opacity duration-300"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar Wrapper */}
      <div className={`
        fixed inset-y-0 left-0 z-50 transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <Sidebar 
          currentPage={currentPage} 
          setCurrentPage={(p) => {
            setCurrentPage(p);
            setIsSidebarOpen(false);
          }} 
          onLogout={() => handleLogin(false)} 
        />
      </div>

      {/* Main Content Area */}
      <main className="flex-1 w-full overflow-y-auto h-screen custom-scrollbar">
        {/* Mobile Header Bar */}
        <div className="md:hidden flex items-center justify-between p-4 bg-white border-b sticky top-0 z-30 shadow-md">
          <div className="flex items-center">
             <span className="font-black text-orange-600 text-xl tracking-tighter">রফিক ইলেকট্রনিক্স</span>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2.5 bg-orange-50 rounded-xl text-orange-600 hover:bg-orange-100 transition-colors"
          >
            {isSidebarOpen ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>

        <div className="p-4 md:p-8 max-w-7xl mx-auto">
          {renderPage()}
        </div>
      </main>
    </div>
  );
};

export default App;
