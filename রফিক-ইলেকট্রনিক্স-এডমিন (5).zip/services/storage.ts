
import { Customer, BillRecord, Package, CustomerStatus } from '../types';

const STORAGE_KEY = 'rafiq_electronics_data';

const DEFAULT_CUSTOMERS: Customer[] = [
  {
    id: '1',
    name: 'রফিক আহমেদ',
    phone: '01752494864',
    userId: 'rafiq_admin',
    password: 'password',
    pppoeUser: 'rafiq001',
    pppoePass: '123456',
    package: Package.THIRTY_MB_RP,
    area: 'চাপড়ী, হাসান মোড়',
    status: CustomerStatus.ACTIVE,
    createdAt: new Date().toISOString()
  }
];

export const getStoredData = (): { customers: Customer[], bills: BillRecord[] } => {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) {
    return { customers: DEFAULT_CUSTOMERS, bills: [] };
  }
  try {
    const parsed = JSON.parse(data);
    // Migration check for missing fields
    const migratedCustomers = parsed.customers.map((c: any) => ({
      ...c,
      pppoeUser: c.pppoeUser || '',
      pppoePass: c.pppoePass || ''
    }));
    return { customers: migratedCustomers, bills: parsed.bills || [] };
  } catch {
    return { customers: DEFAULT_CUSTOMERS, bills: [] };
  }
};

export const setStoredData = (data: { customers: Customer[], bills: BillRecord[] }) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
};
