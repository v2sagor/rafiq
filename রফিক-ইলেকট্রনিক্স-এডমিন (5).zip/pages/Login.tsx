
import React, { useState } from 'react';
import { Phone, Lock, LogIn, AlertCircle } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone === '01752494864' && password === '01752494864') {
      onLoginSuccess();
    } else {
      setError('ফোন নাম্বার অথবা পাসওয়ার্ড ভুল হয়েছে!');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl shadow-slate-200 overflow-hidden border border-white">
        <div className="p-12 text-center pb-8">
          <h1 className="text-3xl font-black text-slate-800 leading-tight">রফিক ইলেকট্রনিক্স</h1>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mt-2">Admin Panel Access</p>
        </div>
        
        <form onSubmit={handleLogin} className="px-10 pb-12 space-y-6">
          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-2xl flex items-center space-x-3 text-sm font-bold border border-red-100 animate-pulse">
              <AlertCircle size={20} />
              <span>{error}</span>
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-xs font-black uppercase tracking-widest text-slate-400 ml-1">ফোন নাম্বার</label>
            <div className="relative group">
              <div className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-orange-500 transition-colors">
                <Phone size={20} />
              </div>
              <input 
                type="text" 
                className="w-full bg-slate-50 border-2 border-transparent focus:border-orange-500 focus:bg-white rounded-2xl px-14 py-4 outline-none transition-all font-bold text-slate-700"
                placeholder="017XXXXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-black uppercase tracking-widest text-slate-400 ml-1">পাসওয়ার্ড</label>
            <div className="relative group">
              <div className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-orange-500 transition-colors">
                <Lock size={20} />
              </div>
              <input 
                type="password" 
                className="w-full bg-slate-50 border-2 border-transparent focus:border-orange-500 focus:bg-white rounded-2xl px-14 py-4 outline-none transition-all font-bold text-slate-700"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-orange-100 transition-all transform active:scale-95 text-lg flex items-center justify-center space-x-3"
          >
            <LogIn size={22} />
            <span>লগিন করুন</span>
          </button>
          
          <div className="text-center pt-6">
            <p className="text-[10px] text-slate-300 font-bold uppercase tracking-widest">© ২০২৪ রফিক ইলেকট্রনিক্স এন্ড নেটওয়ার্ক</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
