
import React, { useState } from 'react';
import { Customer, Package, CustomerStatus } from '../types';
import { 
  Search, 
  UserPlus, 
  Edit3, 
  Trash2, 
  ShieldCheck, 
  ShieldAlert, 
  X, 
  UserCog, 
  KeySquare, 
  Copy, 
  CheckCircle2,
  PhoneCall
} from 'lucide-react';

interface CustomersProps {
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
}

const Customers: React.FC<CustomersProps> = ({ customers, setCustomers }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [copyStatus, setCopyStatus] = useState<string | null>(null);

  const [formData, setFormData] = useState<Partial<Customer>>({
    name: '',
    phone: '',
    userId: '',
    password: '',
    pppoeUser: '',
    pppoePass: '',
    package: Package.TEN_MB,
    area: '',
    status: CustomerStatus.ACTIVE
  });

  const filteredCustomers = customers.filter(c => 
    (c.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.phone || '').includes(searchTerm) ||
    (c.pppoeUser || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.area || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCopy = (text: string, id: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopyStatus(id);
    setTimeout(() => setCopyStatus(null), 2000);
  };

  const handleToggleStatus = (id: string) => {
    setCustomers(prev => prev.map(c => 
      c.id === id ? { ...c, status: c.status === CustomerStatus.ACTIVE ? CustomerStatus.INACTIVE : CustomerStatus.ACTIVE } : c
    ));
  };

  const handleDelete = (id: string) => {
    if (window.confirm('আপনি কি নিশ্চিত যে এই গ্রাহকের তথ্য ডিলিট করতে চান?')) {
      setCustomers(prev => prev.filter(c => c.id !== id));
    }
  };

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setFormData(customer);
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCustomer) {
      setCustomers(prev => prev.map(c => c.id === editingCustomer.id ? { ...c, ...formData as Customer } : c));
    } else {
      const newCustomer: Customer = {
        ...formData as Customer,
        id: Date.now().toString(),
        createdAt: new Date().toISOString()
      };
      setCustomers(prev => [...prev, newCustomer]);
    }
    closeModal();
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingCustomer(null);
    setFormData({
      name: '', phone: '', userId: '', password: '', 
      pppoeUser: '', pppoePass: '',
      package: Package.TEN_MB, area: '', status: CustomerStatus.ACTIVE
    });
  };

  // Ensure no spaces or special characters in the dial link
  const getTelLink = (phone: string) => `tel:${(phone || '').replace(/[^0-9+]/g, '')}`;

  return (
    <div className="space-y-6 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight">গ্রাহক তালিকা</h2>
          <p className="text-slate-500 text-sm md:text-base mt-1 font-medium">গ্রাহকদের তথ্য ও PPPoE ম্যানেজমেন্ট</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-4 rounded-2xl font-bold shadow-lg shadow-orange-100 transition-all active:scale-95 flex items-center justify-center space-x-2 w-full md:w-auto"
        >
          <UserPlus size={20} />
          <span>নতুন গ্রাহক যোগ</span>
        </button>
      </div>

      <div className="bg-white p-2 rounded-2xl shadow-sm border border-slate-100 flex items-center focus-within:border-orange-500 transition-all">
        <div className="p-3 text-slate-400">
          <Search size={22} />
        </div>
        <input 
          type="text"
          placeholder="নাম, ফোন বা PPPoE ইউজার সার্চ..."
          className="w-full bg-transparent focus:outline-none text-base md:text-lg py-3 px-2 text-slate-700 font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Mobile Cards */}
      <div className="grid grid-cols-1 md:hidden gap-5">
        {filteredCustomers.map((customer) => (
          <div key={customer.id} className="bg-white rounded-[2.5rem] p-6 border border-slate-100 shadow-sm space-y-5">
            <div className="flex justify-between items-start">
              <div className="flex items-center space-x-4">
                <div className="w-14 h-14 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center font-black text-2xl border border-orange-100/50">
                  {customer.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-black text-slate-800 text-xl leading-tight">{customer.name}</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{customer.area}</p>
                </div>
              </div>
              <button 
                onClick={() => handleToggleStatus(customer.id)}
                className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                  customer.status === CustomerStatus.ACTIVE ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}
              >
                {customer.status === CustomerStatus.ACTIVE ? 'Active' : 'Inactive'}
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-50">
              <div className="bg-slate-50 p-3 rounded-2xl">
                <p className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-1">প্যাকেজ</p>
                <p className="text-xs font-bold text-slate-700">{customer.package}</p>
              </div>
              <div className="bg-orange-50 p-3 rounded-2xl border border-orange-100/30">
                <p className="text-[10px] font-black uppercase text-orange-400 tracking-wider mb-1">মোবাইল নাম্বার</p>
                <a 
                  href={getTelLink(customer.phone)} 
                  className="flex items-center space-x-1.5 text-orange-600 active:scale-95 transition-transform"
                >
                  <PhoneCall size={14} className="fill-orange-600 text-white" />
                  <p className="text-sm font-black font-mono tracking-tighter underline underline-offset-4 decoration-orange-200">{customer.phone}</p>
                </a>
              </div>
            </div>

            <div className="bg-slate-900 rounded-[1.5rem] p-5 space-y-4 border border-slate-800 shadow-inner">
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                   <span className="font-bold text-[10px] uppercase tracking-widest text-orange-500 mb-1">PPPoE Username</span>
                   <span className="font-black text-white text-2xl font-mono tracking-tight">{customer.pppoeUser || '---'}</span>
                </div>
                <button onClick={() => handleCopy(customer.pppoeUser, customer.id + '-user')} className="p-3 bg-slate-800 rounded-xl text-slate-400 hover:text-white active:scale-90 transition-all border border-slate-700">
                  {copyStatus === customer.id + '-user' ? <CheckCircle2 size={20} className="text-green-500" /> : <Copy size={20} />}
                </button>
              </div>
              <div className="h-[1px] bg-slate-800"></div>
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                   <span className="font-bold text-[10px] uppercase tracking-widest text-orange-500 mb-1">PPPoE Password</span>
                   <span className="font-black text-white text-2xl font-mono tracking-tight">{customer.pppoePass || '---'}</span>
                </div>
                <button onClick={() => handleCopy(customer.pppoePass, customer.id + '-pass')} className="p-3 bg-slate-800 rounded-xl text-slate-400 hover:text-white active:scale-90 transition-all border border-slate-700">
                  {copyStatus === customer.id + '-pass' ? <CheckCircle2 size={20} className="text-green-500" /> : <Copy size={20} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-2">
              <button onClick={() => handleEdit(customer)} className="flex-1 bg-slate-100 text-slate-600 font-bold py-4 rounded-2xl flex items-center justify-center space-x-2 text-sm border active:bg-slate-200 transition-colors">
                <Edit3 size={18} />
                <span>এডিট</span>
              </button>
              <button onClick={() => handleDelete(customer.id)} className="bg-red-50 text-red-500 p-4 rounded-2xl border border-red-100 active:bg-red-100 transition-colors">
                <Trash2 size={20} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Desktop View Table */}
      <div className="hidden md:block bg-white rounded-3xl shadow-md border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400">গ্রাহক</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400">ফোন</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400">PPPoE User</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400">PPPoE Pass</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400 text-center">অবস্থা</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredCustomers.map((customer) => (
                <tr key={customer.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-5">
                    <p className="font-bold text-slate-800">{customer.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold">{customer.area}</p>
                  </td>
                  <td className="px-6 py-5">
                    <a href={getTelLink(customer.phone)} className="flex items-center space-x-2 text-slate-700 hover:text-orange-600 font-bold font-mono">
                      <PhoneCall size={14} className="text-orange-500" />
                      <span>{customer.phone}</span>
                    </a>
                  </td>
                  <td className="px-6 py-5">
                    <span className="text-xl font-black text-slate-800 font-mono tracking-tight">{customer.pppoeUser || '---'}</span>
                  </td>
                  <td className="px-6 py-5">
                    <span className="text-xl font-black text-slate-800 font-mono tracking-tight">{customer.pppoePass || '---'}</span>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <button 
                      onClick={() => handleToggleStatus(customer.id)}
                      className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                        customer.status === CustomerStatus.ACTIVE ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                      }`}
                    >
                      {customer.status === CustomerStatus.ACTIVE ? 'Active' : 'Inactive'}
                    </button>
                  </td>
                  <td className="px-6 py-5 text-right">
                    <div className="flex justify-end space-x-1">
                      <button onClick={() => handleEdit(customer)} className="p-2.5 text-slate-400 hover:text-orange-600 rounded-xl transition-all"><Edit3 size={18} /></button>
                      <button onClick={() => handleDelete(customer.id)} className="p-2.5 text-slate-400 hover:text-red-600 rounded-xl transition-all"><Trash2 size={18} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-end md:items-center justify-center p-0 md:p-4 z-50 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-t-[2.5rem] md:rounded-[3rem] w-full max-w-2xl overflow-hidden shadow-2xl border-t md:border border-white/20 max-h-[95vh] flex flex-col">
            <div className="bg-white border-b border-slate-100 p-6 md:p-8 flex justify-between items-center sticky top-0 z-10">
              <h3 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight">
                {editingCustomer ? 'তথ্য আপডেট' : 'নতুন গ্রাহক যোগ'}
              </h3>
              <button onClick={closeModal} className="p-3 bg-slate-50 text-slate-400 rounded-2xl transition-colors"><X size={24} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-6 overflow-y-auto flex-1 custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">গ্রাহকের নাম</label>
                  <input type="text" required className="w-full bg-slate-50 border-2 border-transparent focus:border-orange-500 rounded-2xl px-5 py-4 outline-none font-bold text-slate-700" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">ফোন নাম্বার</label>
                  <input type="tel" required className="w-full bg-slate-50 border-2 border-transparent focus:border-orange-500 rounded-2xl px-5 py-4 outline-none font-bold text-slate-700 font-mono" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} />
                </div>
                <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6 bg-orange-50/50 p-6 rounded-[2rem] border border-orange-100">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-orange-500 tracking-widest ml-1">PPPoE Username</label>
                    <input type="text" required className="w-full bg-white border-2 border-transparent focus:border-orange-500 rounded-2xl px-5 py-4 outline-none font-bold text-slate-700 font-mono" value={formData.pppoeUser} onChange={(e) => setFormData({...formData, pppoeUser: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-orange-500 tracking-widest ml-1">PPPoE Password</label>
                    <input type="text" required className="w-full bg-white border-2 border-transparent focus:border-orange-500 rounded-2xl px-5 py-4 outline-none font-bold text-slate-700 font-mono" value={formData.pppoePass} onChange={(e) => setFormData({...formData, pppoePass: e.target.value})} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">প্যাকেজ</label>
                  <select className="w-full bg-slate-50 border-2 border-transparent focus:border-orange-500 rounded-2xl px-5 py-4 outline-none font-bold text-slate-700 cursor-pointer" value={formData.package} onChange={(e) => setFormData({...formData, package: e.target.value as Package})}>
                    {Object.values(Package).map(pkg => (<option key={pkg} value={pkg}>{pkg}</option>))}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">ঠিকানা / এরিয়া</label>
                  <input type="text" required className="w-full bg-slate-50 border-2 border-transparent focus:border-orange-500 rounded-2xl px-5 py-4 outline-none font-bold text-slate-700" value={formData.area} onChange={(e) => setFormData({...formData, area: e.target.value})} />
                </div>
              </div>
              <button type="submit" className="w-full py-5 bg-orange-600 text-white rounded-2xl font-black shadow-xl hover:bg-orange-700 transition-all text-lg active:scale-95">
                <span>{editingCustomer ? 'আপডেট নিশ্চিত করুন' : 'নতুন গ্রাহক নিশ্চিত করুন'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;
