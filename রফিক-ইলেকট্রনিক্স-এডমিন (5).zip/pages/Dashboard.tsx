
import React from 'react';
import { Customer, BillRecord, CustomerStatus } from '../types';
import { Users, UserCheck, UserX, Wallet, ArrowUpRight, Clock } from 'lucide-react';

interface DashboardProps {
  customers: Customer[];
  bills: BillRecord[];
  onNavigate?: (page: 'dashboard' | 'customers' | 'billing') => void;
}

const Dashboard: React.FC<DashboardProps> = ({ customers, bills, onNavigate }) => {
  const activeCount = customers.filter(c => c.status === CustomerStatus.ACTIVE).length;
  const inactiveCount = customers.filter(c => c.status === CustomerStatus.INACTIVE).length;
  
  const currentMonth = new Date().toISOString().slice(0, 7);
  const thisMonthPaid = bills
    .filter(b => b.month === currentMonth && b.status === 'paid')
    .reduce((sum, b) => sum + b.amount, 0);

  const stats = [
    { id: 'total', label: 'মোট গ্রাহক', value: customers.length, color: 'text-blue-600', bg: 'bg-blue-50', icon: Users },
    { id: 'active', label: 'এক্টিভ গ্রাহক', value: activeCount, color: 'text-green-600', bg: 'bg-green-50', icon: UserCheck },
    { id: 'inactive', label: 'ইনএক্টিভ গ্রাহক', value: inactiveCount, color: 'text-red-600', bg: 'bg-red-50', icon: UserX },
    { id: 'collection', label: 'মাসিক কালেকশন', value: `${thisMonthPaid}৳`, color: 'text-orange-600', bg: 'bg-orange-50', icon: Wallet },
  ];

  return (
    <div className="space-y-8 animate-fadeIn pb-10">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight">এডমিন ড্যাশবোর্ড</h2>
          <p className="text-slate-500 mt-1">রফিক ইলেকট্রনিক্স নেটওয়ার্ক ম্যানেজমেন্ট</p>
        </div>
        <div className="flex items-center space-x-3 bg-white px-5 py-2.5 rounded-2xl shadow-sm border border-slate-100">
          <Clock size={18} className="text-orange-500" />
          <span className="text-sm font-bold text-slate-600">
            {new Date().toLocaleDateString('bn-BD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.id} className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm hover:shadow-md transition-shadow cursor-default group">
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.bg} ${stat.color} p-3 rounded-2xl group-hover:scale-110 transition-transform`}>
                  <Icon size={24} strokeWidth={2.5} />
                </div>
                <div className="text-slate-300">
                  <ArrowUpRight size={20} />
                </div>
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-wider">{stat.label}</p>
              <h3 className="text-3xl font-black text-slate-800 mt-1">{stat.value}</h3>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex items-center justify-between">
            <h3 className="text-lg font-bold text-slate-800">সাম্প্রতিক গ্রাহক</h3>
            <button 
              onClick={() => onNavigate && onNavigate('customers')}
              className="text-sm font-bold text-orange-600 hover:text-orange-700 hover:underline transition-all"
            >
              সবগুলো দেখুন
            </button>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {customers.slice(-5).reverse().map((c) => (
                <div key={c.id} className="flex items-center justify-between p-4 bg-slate-50/50 rounded-2xl border border-slate-50">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 font-black text-lg shadow-sm">
                      {c.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-slate-800">{c.name}</p>
                      <p className="text-xs text-slate-500 font-semibold uppercase">{c.area}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                      c.status === CustomerStatus.ACTIVE ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {c.status === CustomerStatus.ACTIVE ? 'Active' : 'Inactive'}
                    </span>
                    <p className="text-[10px] text-slate-400 mt-1 font-bold">{new Date(c.createdAt).toLocaleDateString('bn-BD')}</p>
                  </div>
                </div>
              ))}
              {customers.length === 0 && (
                <div className="text-center py-10">
                  <Users size={40} className="mx-auto text-slate-200 mb-2" />
                  <p className="text-slate-400 font-bold">কোন ডাটা পাওয়া যায়নি</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-orange-600 rounded-3xl p-8 text-white flex flex-col justify-between shadow-xl shadow-orange-100 relative overflow-hidden group">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-orange-500 rounded-full opacity-50 blur-3xl group-hover:scale-125 transition-transform duration-700"></div>
          <div className="relative z-10">
            <h3 className="text-xl font-bold mb-2">সিস্টেম স্ট্যাটাস</h3>
            <p className="text-orange-100 text-sm font-medium">আপনার নেটওয়ার্ক বর্তমানে সচল রয়েছে।</p>
          </div>
          <div className="mt-10 relative z-10">
            <div className="flex justify-between items-end">
              <div>
                <p className="text-4xl font-black">১০০%</p>
                <p className="text-xs uppercase font-bold tracking-widest text-orange-200 mt-1">Uptime Guaranteed</p>
              </div>
              <div className="w-16 h-1 bg-white/30 rounded-full overflow-hidden">
                <div className="w-full h-full bg-white animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
