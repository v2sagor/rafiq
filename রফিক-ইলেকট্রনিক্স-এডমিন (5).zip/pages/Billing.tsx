
import React, { useState, useMemo } from 'react';
import { Customer, BillRecord } from '../types';
import { Calendar, Search, CheckCircle2, CircleDashed, Banknote, Users2, ChevronDown } from 'lucide-react';

interface BillingProps {
  customers: Customer[];
  bills: BillRecord[];
  setBills: React.Dispatch<React.SetStateAction<BillRecord[]>>;
}

const Billing: React.FC<BillingProps> = ({ customers, bills, setBills }) => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [searchTerm, setSearchTerm] = useState('');

  // Generates 6 months back and 6 months forward from now correctly
  const months = useMemo(() => {
    const monthsArray = [];
    const today = new Date();
    for (let i = -6; i <= 6; i++) {
      const d = new Date(today.getFullYear(), today.getMonth() + i, 1);
      monthsArray.push(d.toISOString().slice(0, 7));
    }
    return monthsArray.reverse();
  }, []);

  const getStatus = (customerId: string) => {
    const bill = bills.find(b => b.customerId === customerId && b.month === selectedMonth);
    return bill ? bill.status : 'unpaid';
  };

  const toggleBill = (customerId: string, packageText: string) => {
    const existingBill = bills.find(b => b.customerId === customerId && b.month === selectedMonth);
    
    // Extract amount from package text (e.g., "১০ এমবি ৳৫২৫" -> 525)
    const amountMatch = packageText.match(/৳(\d+)/);
    const amount = amountMatch ? parseInt(amountMatch[1]) : 500;

    if (existingBill) {
      if (existingBill.status === 'paid') {
        // Toggle back to unpaid (remove the paid record)
        setBills(prev => prev.filter(b => b.id !== existingBill.id));
      }
    } else {
      // Create new paid record
      const newBill: BillRecord = {
        id: Date.now().toString(),
        customerId,
        month: selectedMonth,
        amount,
        status: 'paid',
        paidDate: new Date().toISOString()
      };
      setBills(prev => [...prev, newBill]);
    }
  };

  const filteredCustomers = customers.filter(c => 
    (c.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.phone || '').includes(searchTerm) ||
    (c.pppoeUser || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPaid = bills.filter(b => b.month === selectedMonth && b.status === 'paid').length;
  const totalAmount = bills
    .filter(b => b.month === selectedMonth && b.status === 'paid')
    .reduce((sum, b) => sum + b.amount, 0);

  return (
    <div className="space-y-8 pb-20 animate-fadeIn">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h2 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight">বিলিং কালেকশন</h2>
          <p className="text-slate-500 mt-1 font-medium">গ্রাহকদের মাসিক পেমেন্ট এখানে এন্ট্রি দিন</p>
        </div>
        
        <div className="relative w-full lg:w-auto">
          <div className="flex items-center space-x-3 bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
            <div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl">
              <Calendar size={20} />
            </div>
            <div className="flex flex-col pr-10">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">সিলেক্ট মাস</span>
              <select 
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent focus:outline-none font-black text-slate-800 cursor-pointer appearance-none text-base"
              >
                {months.map(m => (
                  <option key={m} value={m}>
                    {new Date(m + '-01').toLocaleDateString('bn-BD', { month: 'long', year: 'numeric' })}
                  </option>
                ))}
              </select>
            </div>
            <ChevronDown size={20} className="absolute right-4 text-slate-400 pointer-events-none" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm flex items-center space-x-6">
          <div className="bg-green-100 text-green-600 p-5 rounded-[1.5rem]">
            <Users2 size={32} />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">পরিশোধিত গ্রাহক</p>
            <h3 className="text-3xl md:text-5xl font-black text-slate-800 tracking-tighter">{totalPaid} জন</h3>
          </div>
        </div>
        <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm flex items-center space-x-6">
          <div className="bg-orange-100 text-orange-600 p-5 rounded-[1.5rem]">
            <Banknote size={32} />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">মোট কালেকশন</p>
            <h3 className="text-3xl md:text-5xl font-black text-slate-800 tracking-tighter">{totalAmount}৳</h3>
          </div>
        </div>
      </div>

      <div className="bg-white p-2 rounded-2xl shadow-sm border border-slate-100 flex items-center focus-within:border-orange-500 transition-all">
        <div className="p-3 text-slate-400">
          <Search size={22} />
        </div>
        <input 
          type="text"
          placeholder="গ্রাহকের নাম বা PPPoE ইউজার সার্চ..."
          className="w-full bg-transparent focus:outline-none text-base md:text-lg py-3 px-2 text-slate-700 font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Mobile View: List of Cards */}
      <div className="grid grid-cols-1 md:hidden gap-5">
        {filteredCustomers.length > 0 ? filteredCustomers.map((c) => {
          const status = getStatus(c.id);
          const pkgAmount = c.package.match(/৳(\d+)/)?.[1] || '---';
          return (
            <div key={c.id} className="bg-white rounded-[2rem] p-6 border border-slate-100 shadow-sm space-y-5">
              <div className="flex justify-between items-start">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center font-black text-slate-400">
                    {c.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-black text-slate-800 text-lg leading-tight">{c.name}</h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">PPPoE: {c.pppoeUser || 'N/A'}</p>
                  </div>
                </div>
                <span className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center space-x-1 ${
                  status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                }`}>
                  {status === 'paid' ? <CheckCircle2 size={12} /> : <CircleDashed size={12} />}
                  <span>{status === 'paid' ? 'Paid' : 'Unpaid'}</span>
                </span>
              </div>
              
              <div className="flex justify-between items-center bg-slate-50 p-4 rounded-2xl border border-slate-100">
                 <div>
                    <p className="text-[10px] font-black uppercase text-slate-400 mb-0.5">টাকার পরিমাণ</p>
                    <p className="text-xl font-black text-slate-800">{pkgAmount}৳</p>
                 </div>
                 <button 
                  onClick={() => toggleBill(c.id, c.package)}
                  className={`px-7 py-3.5 rounded-2xl font-black text-xs uppercase transition-all shadow-md active:scale-90 ${
                    status === 'paid' 
                    ? 'bg-red-50 text-red-500 border border-red-100' 
                    : 'bg-orange-600 text-white'
                  }`}
                >
                  {status === 'paid' ? 'রিমুভ' : 'পেমেন্ট নিন'}
                </button>
              </div>
            </div>
          )
        }) : (
          <div className="text-center py-10 bg-white rounded-3xl border border-dashed border-slate-200">
             <p className="text-slate-400 font-bold">কোন গ্রাহক পাওয়া যায়নি</p>
          </div>
        )}
      </div>

      {/* Desktop View: Table */}
      <div className="hidden md:block bg-white rounded-3xl shadow-md border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400">গ্রাহক ও PPPoE</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400">প্যাকেজ</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400">টাকার পরিমাণ</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400 text-center">স্ট্যাটাস</th>
                <th className="px-6 py-5 text-[10px] font-black uppercase tracking-widest text-slate-400 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredCustomers.map((c) => {
                const status = getStatus(c.id);
                return (
                  <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-5">
                      <p className="font-bold text-slate-800">{c.name}</p>
                      <p className="text-[10px] font-black uppercase text-slate-400">U: {c.pppoeUser || '---'}</p>
                    </td>
                    <td className="px-6 py-5">
                      <span className="text-[11px] font-black bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg">
                        {c.package}
                      </span>
                    </td>
                    <td className="px-6 py-5">
                      <p className="font-black text-orange-600 text-base">{c.package.match(/৳(\d+)/)?.[1] || '---'}৳</p>
                    </td>
                    <td className="px-6 py-5 text-center">
                      <span className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                        status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {status === 'paid' ? <CheckCircle2 size={14} /> : <CircleDashed size={14} />}
                        <span>{status === 'paid' ? 'Paid' : 'Unpaid'}</span>
                      </span>
                    </td>
                    <td className="px-6 py-5 text-right">
                      <button 
                        onClick={() => toggleBill(c.id, c.package)}
                        className={`px-5 py-2.5 rounded-xl font-black text-xs uppercase transition-all shadow-sm active:scale-95 ${
                          status === 'paid' 
                          ? 'bg-red-50 text-red-500 border border-red-100' 
                          : 'bg-orange-600 text-white'
                        }`}
                      >
                        {status === 'paid' ? 'রিমুভ করুন' : 'পেমেন্ট নিন'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filteredCustomers.length === 0 && (
             <div className="text-center py-20 bg-slate-50/20">
               <p className="text-slate-400 font-bold">কোন ডাটা পাওয়া যায়নি</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Billing;
