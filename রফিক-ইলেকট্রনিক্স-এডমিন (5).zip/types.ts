
export enum Package {
  TEN_MB = "১০ এমবি ৳৫২৫",
  TWENTY_MB = "২০ এমবি ৳৫৯৯",
  THIRTY_MB = "৩০ এমবি ৳৬৯৯",
  THIRTY_MB_RP = "৩০ এমবি (RP) ৳৯৯৮",
  FORTY_MB = "৪০ এমবি ৳৮৯৯",
  FORTY_MB_RP = "৪০ এমবি (RP) ৳১১৯৮",
  FIFTY_MB = "৫০ এমবি ৳১০৯৯",
  FIFTY_MB_RP = "৫০ এমবি (RP) ৳১৩৯৮",
  SEVENTY_FIVE_MB = "৭৫ এমবি ৳১৫৯৯",
  SEVENTY_FIVE_MB_RP = "৭৫ এমবি (RP) ৳১৮৯৮",
  CUSTOM = "কাস্টম প্যাকেজ"
}

export enum CustomerStatus {
  ACTIVE = "active",
  INACTIVE = "inactive"
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  userId: string;
  password: string;
  pppoeUser: string;    // Added PPPoE Username
  pppoePass: string;    // Added PPPoE Password
  package: Package;
  area: string;
  status: CustomerStatus;
  createdAt: string;
}

export interface BillRecord {
  id: string;
  customerId: string;
  month: string; 
  amount: number;
  status: 'paid' | 'unpaid';
  paidDate?: string;
}
