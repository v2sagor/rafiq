const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

// Serve static files with correct MIME types for React/TSX
app.use(express.static(__dirname, {
    setHeaders: (res, filePath) => {
        if (filePath.endsWith('.tsx') || filePath.endsWith('.ts')) {
            res.setHeader('Content-Type', 'application/javascript');
        }
    }
}));

// Route for health check
app.get('/status', (req, res) => {
    res.send('Server is running perfectly!');
});

// Fallback to index.html for Single Page Application
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});